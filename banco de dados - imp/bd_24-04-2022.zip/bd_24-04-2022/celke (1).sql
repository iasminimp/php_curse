-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 24-Jan-2022 às 11:38
-- Versão do servidor: 5.7.31
-- versão do PHP: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `celke`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `acessos`
--

DROP TABLE IF EXISTS `acessos`;
CREATE TABLE IF NOT EXISTS `acessos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aula_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `acessos`
--

INSERT INTO `acessos` (`id`, `ip`, `nome`, `aula_id`, `user_id`, `created`, `modified`) VALUES
(1, '201.22.16.103', 'DISTINCT', 1, 5, '2021-11-07 08:57:31', NULL),
(2, '201.22.16.104', 'DISTINCT', 1, 5, '2021-11-07 08:59:26', NULL),
(3, '201.22.16.103', 'ORDER BY', 2, 5, '2021-11-07 08:59:26', NULL),
(4, '201.22.16.104', 'ORDER BY', 2, 5, '2021-11-07 09:00:25', NULL),
(5, '201.22.16.108', 'DISTINCT', 4, 6, '2021-11-08 09:01:03', NULL),
(6, '201.22.16.24', 'WHERE', 3, 7, '2021-11-08 09:01:50', NULL),
(7, '201.22.16.204', 'LIMIT', 4, 7, '2021-11-08 09:01:50', NULL),
(8, '201.22.16.107', 'SELECT', 4, 6, '2021-11-08 09:01:50', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `contacts_msgs`
--

DROP TABLE IF EXISTS `contacts_msgs`;
CREATE TABLE IF NOT EXISTS `contacts_msgs` (
  `id` int(11) NOT NULL,
  `name` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `contatos`
--

DROP TABLE IF EXISTS `contatos`;
CREATE TABLE IF NOT EXISTS `contatos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `telefone` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `celular` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `contatos`
--

INSERT INTO `contatos` (`id`, `telefone`, `celular`, `whatsapp`, `user_id`, `created`, `modified`) VALUES
(1, '(41) 90000-0000', '(41) 98861-0440', '(41) 98861-0440', 1, '2020-04-23 00:00:00', NULL),
(2, '(41) 91111-1111', '(41) 92222-2222', NULL, 2, '2020-04-23 00:00:00', NULL),
(3, '2222222222', '12121 4545454', '212132 454654', 2, '2021-11-16 15:30:15', NULL),
(4, '27 999090753', '27 999456006', '4002 8922', 5, '2021-11-16 15:30:37', '2021-11-22 12:12:16'),
(5, '27 999090753', '27 999456006', '4002 8922', 5, '2021-11-16 15:33:07', '2021-11-22 12:12:16');

-- --------------------------------------------------------

--
-- Estrutura da tabela `enderecos`
--

DROP TABLE IF EXISTS `enderecos`;
CREATE TABLE IF NOT EXISTS `enderecos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logradouro` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro` varchar(220) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `complemento` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `enderecos`
--

INSERT INTO `enderecos` (`id`, `logradouro`, `numero`, `bairro`, `cidade`, `complemento`, `user_id`, `created`, `modified`) VALUES
(1, 'Av. Winston Churchill', '936', 'Capão Raso', 'Curitiba', NULL, 1, '2020-04-23 00:00:00', NULL),
(2, 'Rua Marechal Deodoro', '630', 'Centro', 'Curitiba', 'Teste de Complemento', 4, '2020-04-23 00:00:00', '2021-11-22 12:46:35'),
(3, '53', '06', 'Santo Antonio', 'SÃ£o Mateus', '-', 5, '2021-11-16 15:44:17', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `niveis_acessos`
--

DROP TABLE IF EXISTS `niveis_acessos`;
CREATE TABLE IF NOT EXISTS `niveis_acessos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `niveis_acessos`
--

INSERT INTO `niveis_acessos` (`id`, `nome`, `created`, `modified`) VALUES
(1, 'Super Administrador', '2020-04-23 00:00:00', NULL),
(2, 'Administrador', '2020-04-23 00:00:00', NULL),
(3, 'Aluno', '2020-04-23 00:00:00', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sits_users`
--

DROP TABLE IF EXISTS `sits_users`;
CREATE TABLE IF NOT EXISTS `sits_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `sits_users`
--

INSERT INTO `sits_users` (`id`, `nome`, `created`, `modified`) VALUES
(1, 'Ativo', '2020-04-23 00:00:00', NULL),
(2, 'Inativo', '2020-04-23 00:00:00', NULL),
(3, 'Aguardando confirmação', '2020-04-23 00:00:00', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(220) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `senha` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sits_user_id` int(11) NOT NULL,
  `niveis_acesso_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sits_user_id` (`sits_user_id`),
  KEY `niveis_acesso_id` (`niveis_acesso_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `nome`, `email`, `senha`, `sits_user_id`, `niveis_acesso_id`, `created`, `modified`) VALUES
(1, 'Cesar', 'cesar@celke.com.br', '123456', 1, 1, '2020-04-23 00:00:00', NULL),
(2, 'Kelly', 'kelly@celk.com.br', '123456', 2, 2, '2020-04-23 00:00:00', NULL),
(4, 'Marcos', 'marcos@celke.com.br', '123456', 1, 3, '2020-04-23 00:00:00', NULL),
(5, 'Gabriele Com E', 'gabriele@celke.com.br', '123456', 1, 2, '2020-04-23 00:00:00', '2021-11-22 09:43:39'),
(6, 'Iasmin', 'iasmin@email.com', '123456', 2, 2, '2021-11-08 11:18:07', NULL),
(7, 'iasmin', 'iasmin@gmail.com', '123456', 1, 1, '2021-11-08 12:07:13', NULL),
(8, 'Antonio Venturine', 'antonio@email.com', '123456', 3, 3, '2021-11-16 14:49:55', '2021-11-29 10:05:30'),
(9, 'iasmin', 'asdasd@email.com', '123456', 1, 3, '2021-11-26 08:37:47', NULL);

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `contatos`
--
ALTER TABLE `contatos`
  ADD CONSTRAINT `contatos_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `enderecos`
--
ALTER TABLE `enderecos`
  ADD CONSTRAINT `enderecos_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`niveis_acesso_id`) REFERENCES `niveis_acessos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`sits_user_id`) REFERENCES `sits_users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
