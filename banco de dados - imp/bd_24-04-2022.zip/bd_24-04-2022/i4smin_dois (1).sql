-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 24-Jan-2022 às 11:38
-- Versão do servidor: 5.7.31
-- versão do PHP: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `i4smin_dois`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `adms_confs_emails`
--

DROP TABLE IF EXISTS `adms_confs_emails`;
CREATE TABLE IF NOT EXISTS `adms_confs_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `host_server` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `smtpsecure` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `port` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `adms_confs_emails`
--

INSERT INTO `adms_confs_emails` (`id`, `title`, `name`, `email`, `host_server`, `username`, `password`, `smtpsecure`, `port`, `created`, `modified`) VALUES
(1, 'Atendimento', 'Atendimento da Empresa', 'atendimento@iasmin.com.br', 'smtp.mailtrap.io', 'e3860a258d5fd9', '75093fde25ce3c', 'tls', 2525, '2022-01-14 11:11:28', NULL),
(2, 'Suporte', 'Suporte da Empresa', 'suporte@iasmin.com.br', 'smtp.mailtrap.io', 'e3860a258d5fd9', '75093fde25ce3c', 'tls', 2525, '2022-01-14 11:26:02', NULL),
(3, 'Não Responder', 'Não Responder da Empresa X', 'noreply@iasmin.com.br', 'smtp.mailtrap.io', 'e3860a258d5fd9', '75093fde25ce3c', 'tls', 2525, '2022-01-14 11:26:02', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `adms_users`
--

DROP TABLE IF EXISTS `adms_users`;
CREATE TABLE IF NOT EXISTS `adms_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nickname` varchar(44) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(220) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recover_password` varchar(220) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conf_email` varchar(220) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(220) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adms_sits_user_id` int(11) NOT NULL DEFAULT '3',
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `adms_users`
--

INSERT INTO `adms_users` (`id`, `name`, `nickname`, `email`, `username`, `password`, `recover_password`, `conf_email`, `image`, `adms_sits_user_id`, `created`, `modified`) VALUES
(1, 'Iasmin', NULL, 'iasmin@email.com', 'iasminimp', '$2y$10$7OQxCr4NA24EoYJvXfjFn.SJL.yiH41xi.56GDLQn0/HxhyAo56qS', NULL, NULL, NULL, 1, '2022-01-03 09:35:37', NULL),
(2, 'iasmin2', NULL, 'iasmin2@gmail.com', 'iasminimp', '$2y$10$7OQxCr4NA24EoYJvXfjFn.SJL.yiH41xi.56GDLQn0/HxhyAo56qS', NULL, NULL, NULL, 1, '2021-10-22 09:13:46', NULL),
(3, 'antonio', NULL, 'antonio@email.com', '', '123456a', NULL, NULL, NULL, 3, '2022-01-07 11:33:32', NULL),
(4, 'Fabinho', NULL, 'fabio@gmail.com', NULL, '$2y$10$7Z2kx2w0UV.g1WixwOBj5efk5hUK6Rb8K4ezfkci/dSZkaoV8ztnO', NULL, NULL, NULL, 3, '2022-01-10 09:07:57', NULL),
(5, 'asdasdasd', NULL, 'iasmin@gmail.com', NULL, '$2y$10$2CJe6IS.vHmVWKMLLZA74OyeqUhwkEPM.fbIbyhEWwtOX1qye1nmO', NULL, NULL, NULL, 3, '2022-01-10 09:09:17', NULL),
(6, 'asdasdasd', NULL, 'iasmin@gmail.com', NULL, '$2y$10$22cFdOGflKN4.2wdu0mexeUXkHNeji7gkbwEWqW7sQpWvvZ/6wG/W', NULL, NULL, NULL, 3, '2022-01-10 09:09:24', NULL),
(7, 'asdasdasd', NULL, 'iasmin@gmail.com', NULL, '$2y$10$exGXpJm13eTDqKDInaEK6uDhu9YwHCm/AXqAytAxzaGcHR2QQOt1i', NULL, NULL, NULL, 3, '2022-01-10 09:09:31', NULL),
(8, 'asdasdasd', NULL, 'iasmin@gmail.com', NULL, '$2y$10$F4Ege9Zrg5K1jsNh3IeYSu4q30LjCkhmq9cphieGweiqOU9GV0mpS', NULL, NULL, NULL, 3, '2022-01-10 09:09:34', NULL),
(9, 'asdasdasd', NULL, 'iasmin@gmail.com', NULL, '$2y$10$2yC/NWf5dSnOIKEYSF00eebVwNO1XHddQ9QFnGHN2BWy5tZqHZIw2', NULL, NULL, NULL, 3, '2022-01-10 09:53:07', NULL),
(10, 'asdasdasd', NULL, 'iasmin@gmail.com', NULL, '$2y$10$0fM7pSI/XcmkjwTR1dnmDeschv9IoIDbG/rpk5UgSEZRvbbPJNUKa', NULL, NULL, NULL, 3, '2022-01-10 10:09:05', NULL),
(11, 'asdasdasd', NULL, 'iasminasd@gmail.com', NULL, '$2y$10$nHL19G3K8z22aonoxvBFV.JhQs0PL2q332UAhkVJn6UiK7WcC1Vza', NULL, NULL, NULL, 3, '2022-01-10 12:10:37', NULL),
(12, 'Iasmin Marques', NULL, 'iasmin@gmail.com', NULL, '$2y$10$B21AjgZ06.sgCfO7qTEQAOP3LdmFQeGazRdqK.21AMGi7bEKvWbWm', NULL, NULL, NULL, 3, '2022-01-14 09:52:02', NULL),
(13, 'Iasmin Marques', NULL, 'iasmin@gmail.com', NULL, '$2y$10$4.zTdRFijqWrX/O3zT3g6.xgeHe.UJpoG4GYxwcGL2KVzBo.MiMeu', NULL, NULL, NULL, 3, '2022-01-14 09:52:51', NULL),
(14, 'Iasmin Marques', NULL, 'iasmin@gmail.com', NULL, '$2y$10$AGwtzad2AQVJMA1KmkIRguU/hlvmCWFgBDcx4ao0ecouBxY5iYf.u', NULL, NULL, NULL, 3, '2022-01-14 09:59:35', NULL),
(15, 'Ernanda', NULL, 'ernanda@gmail.com', NULL, '$2y$10$rqi0NYHd80V1BUWeDP0noelX6ifVeQcpIN8nZ5g0z39/4p39dWPem', NULL, '$2y$10$rx7Q8CcygBTppWUem.eTsuSHBCeB8yUgI.55CjYs9z.SsP/n2d7HS', NULL, 3, '2022-01-14 10:15:59', NULL),
(16, 'Ernanda', NULL, 'ernanda@gmail.com', NULL, '$2y$10$fxABt28gphyGtV4LwyZw6OTBQ7z/GflM6QmEJfJHIj1s4JGg11TcG', NULL, '$2y$10$a0104Xpd28p7Ce/qiA9wgOHtopLI4SG72RQy4uZuP47ETZKhm8QYS', NULL, 3, '2022-01-14 11:35:06', NULL),
(17, 'Ernanda', NULL, 'ernanda@gmail.com', NULL, '$2y$10$VFECcU7AjxCwWuvDBEimYeCMp/UXtXMkJszXiRludR6aGvFQIrZl6', NULL, '$2y$10$C1sjsqlDJViTdJfjdTLtZe/mZN/VBbfumuY6j00jdETEcS9QFwTiq', NULL, 3, '2022-01-14 11:55:32', NULL),
(18, 'Fabinho', NULL, 'fabinho@email.com', NULL, '$2y$10$XnSLbG4BkI0ccajPae8XL.Wum2AnOqE7ehGfPdsZl8EBmzQ4Wd9Cy', NULL, '$2y$10$okkx4x6rJbdNntUAY0rMnenxTOQ9NzetPO1ZPBp6zpS1LLjR4f7P6', NULL, 3, '2022-01-14 11:59:47', NULL),
(19, 'Fabinho', NULL, 'fabinho@email.com', NULL, '$2y$10$skGVmRAuZAKmcdX.wnj73.py85TQZ50bFqw/6GlwbUPpXCaHphlH2', NULL, '$2y$10$acb4PfOGcJgmDxT/03Zt3OJThFCnnYPS96Y8ao5Voj08/NQMKowm6', NULL, 3, '2022-01-14 12:00:49', NULL),
(20, 'Fabinho', NULL, 'fabinho@email.com', NULL, '$2y$10$h8x7hs8J9uVlCkUdOTBSqe99dyaUMO9RMmG9zk.suwqOqdWTbM3a2', NULL, '$2y$10$RWapDrUQJydyweP1E.SwkeoypB4KH1K1ta32oVzOYxjPLch/R8GqK', NULL, 3, '2022-01-14 12:01:08', NULL),
(21, 'Fabinho', NULL, 'fabinho@email.com', NULL, '$2y$10$plEXYlpg3UryG9BTM/LOZe6yRXjtpH7FxofgmzDUs5FEqXGFrHaEe', NULL, '$2y$10$szveqNivoIxur77dwSPpUe509z9hMwkKW9ElGOLcTuiJH9HXt9PFC', NULL, 3, '2022-01-14 12:05:13', NULL),
(22, 'Fabinho', NULL, 'fabinho@email.com', NULL, '$2y$10$Ibf4F31KScP0kGTu8rzF0ezm5v.M8pgBtmEreux6QIdDqhVpoYt7q', NULL, '$2y$10$tEbn3.W4R2GvNrnY9hfPse8uTGQTl/VFpI86hubAL9rtz1qrHuihW', NULL, 3, '2022-01-14 12:10:07', NULL),
(23, 'Ernanda', NULL, 'ernanda@gmail.com', NULL, '$2y$10$IKVTKGUiTNUuxT7S0pmxSeGzpAcW8LcB/qpdS/3Z.r63WKnd2puTK', NULL, '$2y$10$if0/EpmErpDOZbVdKBxXou8olaieelHgmy6p5rXpuYW4tgHA2oRmi', NULL, 3, '2022-01-14 12:25:55', NULL),
(24, 'Ernanda', NULL, 'ernanda@gmail.com', NULL, '$2y$10$YyfMhzlLjTkDqhOCewuVletNq91.VOrRLk9XAGFxW2tSGY0dMgIDa', NULL, '$2y$10$/agoHVJLTHD1G.ElZud7vOUX9kT8TPFK8hnH/VySlukvx50WpFO7e', NULL, 3, '2022-01-14 12:29:04', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `adm_sits_users`
--

DROP TABLE IF EXISTS `adm_sits_users`;
CREATE TABLE IF NOT EXISTS `adm_sits_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(44) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `adm_sits_users`
--

INSERT INTO `adm_sits_users` (`id`, `name`, `created`, `modified`) VALUES
(1, 'Ativo', '2022-01-01 09:29:13', NULL),
(2, 'Inativo', '2022-01-01 09:29:13', NULL),
(3, 'Aguardando Confirmação', '2022-01-04 09:29:13', NULL),
(4, 'Spam', '2022-01-03 09:29:13', NULL),
(5, 'Descadastrado', '2022-01-04 09:29:13', NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
